import React from 'react';
//import '../style.css';

const Footer = () => {
  return (
    <footer>
      <div className="grass"></div>
      <div className="grass"></div>
      <div className="grass"></div>
      <div className="grass"></div>
      <div className="grass"></div>
    </footer>
  );
};

export default Footer;

// import React from "react";
// import "./Footer.css"; // Ensure you have this CSS file

// const Footer = () => {
//   return (
//     <footer className="footer">
//       {[...Array(5)].map((_, i) => (
//         <div key={i} className="grass"></div>
//       ))}
//     </footer>
//   );
// };

// export default Footer;
