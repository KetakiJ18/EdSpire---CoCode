import React from 'react';
//import '../style.css';
import { Link } from 'react-router-dom';

const Header = () => (
  <header>
    <div className="logo">SmallTown EduTech</div>
  </header>
);

export default Header;